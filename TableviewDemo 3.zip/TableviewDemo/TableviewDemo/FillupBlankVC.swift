//
//  FillupBlankVC.swift
//  TableviewDemo
//
//  Created by Nirav Joshi on 10/10/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit

class FillupBlankVC: UIViewController {
@IBOutlet var starButtons: [UILabel]!
    var AryAnswer = NSMutableArray()
    var currentIndex : Int = 0
    var ArySuggestion : NSArray = [["11","22","33","44","55","66","77","88"],["1","2","3","4","5","6","7","8"],["11","22","33","44","55","66","77","88"],["111","222","333","444","555","666","777","888"],["1","2","3","4","5","6","7","8"],["11","22","33","44","55","66","77","88"],["111","222","333","444","555","666","777","888"]]
    @IBOutlet weak var btnNext: UIButton!
    @IBOutlet weak var btnPrevious: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        SetSuggestionLabel(SetIndex: currentIndex)
        // Do any additional setup after loading the view.
        
    }
    
    @objc func lblTapGesture(sender: UITapGestureRecognizer) {
        let yourTag = sender.view!.tag // this is the tag of your gesture's object

        print(yourTag)
        print((sender.view as! UILabel).text!)
    
    }
    
    func SetSuggestionLabel(SetIndex : Int) {
        for (index,lbltitle) in starButtons.enumerated()
        {
            lbltitle.text = (ArySuggestion[SetIndex] as! Array)[index]
            lbltitle.isUserInteractionEnabled = true
            let lblTapEvent = UITapGestureRecognizer(target: self, action: #selector(lblTapGesture(sender:)))
            lbltitle.addGestureRecognizer(lblTapEvent)
            
            //            let lblPanEvent = UIPanGestureRecognizer(target: self, action: #selector(lblPanGesture(sender:)))
            //            lbltitle.addGestureRecognizer(lblPanEvent)
        }
    }
    
    @IBAction func btnPreviousClick(_ sender: Any) {
        btnNext.isHidden = false
        if currentIndex >= 0 {
            currentIndex -= 1
            if currentIndex == 0
            {
                btnPrevious.isHidden = true
            }
            SetSuggestionLabel(SetIndex: currentIndex)
        }
    }
    
    @IBAction func btnNextClick(_ sender: Any) {
        btnPrevious.isHidden = false
        if currentIndex <= ArySuggestion.count - 1 {
            currentIndex += 1
            SetSuggestionLabel(SetIndex: currentIndex)
            if currentIndex == ArySuggestion.count - 1
            {
                btnNext.isHidden = true
            }
            
        }
    }
    
//    @objc func lblPanGesture(sender: UIPanGestureRecognizer) {
////        self.view.bringSubviewToFront((sender.view as! UILabel))
////        let translation = sender.translation(in: self.view)
////        (sender.view as! UILabel).center = CGPoint(x: (sender.view as! UILabel).center.x + translation.x, y: (sender.view as! UILabel).center.y + translation.y)
////        sender.setTranslation(CGPoint.zero, in: self.view)
//
//        let translation = sender.translation(in: self.view)
//        if let myView = sender.view {
//            myView.center = CGPoint(x: myView.center.x + translation.x, y: myView.center.y + translation.y)
//        }
//        sender.setTranslation(CGPoint.zero, in: self.view)
//    }
}

