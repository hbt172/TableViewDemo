//
//  ReorderTableCell.swift
//  TableviewDemo
//
//  Created by Nirav Joshi on 09/10/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit

class ReorderTableCell: UITableViewCell {
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var objView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
