//
//  ViewController.swift
//  TableviewDemo
//
//  Created by Nirav Joshi on 09/10/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var btnSelectedAns = UIButton()
    
    @IBOutlet weak var btnAnswer: UIButton!
    @IBOutlet weak var btnPrevious: UIButton!
    @IBOutlet weak var btnNext: UIButton!
    @IBOutlet weak var lblQuestion: UILabel!
    
    @IBOutlet weak var btnAns1: UIButton!
    @IBOutlet weak var HeightBtnAns1: NSLayoutConstraint!
    
    @IBOutlet weak var btnAns2: UIButton!
    @IBOutlet weak var HeightBtnAns2: NSLayoutConstraint!
    
    @IBOutlet weak var btnAns3: UIButton!
    @IBOutlet weak var HeightBtnAns3: NSLayoutConstraint!
    
    @IBOutlet weak var btnAns4: UIButton!
    @IBOutlet weak var HeightBtnAns4: NSLayoutConstraint!
    var currentIndex : Int = 0
    
    let aryDetails : NSArray = [["Which of the following most accurately summarizes the opinion of the author in the text?","Unlike proposed earlier, The Statue of Liberty wasn't erected by the joint effort of both the countries, rather it was a French gift to the Americans.","Laboulaye was never of the opinion that the memorial should be erected by utilizing the resources of France only.","The Statue of Liberty was fully built in the year 1870 by Bartholdi","The idea to build The Statue of Liberty was originated in America."],
                                ["Which of the following, most accurately summarizes the opinion of the author in the text?","He has a firm belief that until today no one has been able to replace Rembrandt's art.","He tried to prove that Rembrandt has not been completely understood by the critics.","He tried to portray that even though Rembrandt was highly regarded in the art world, his prowess and mettle was understood by only a few.","Rembrandt never believed in self-praise and publicizing, rather he was a silent artist."],
                                ["""
Dubai will now have its own Taj Mahal, a replica of the one located in India, which is considered one of the world’s Seven Wonders. It will be named Taj Arabia, and it will be a glass structure inspired by the shape of the Taj Mahal. Also, it will be 20 storeys high. The final work is expected to be finished by 2016, and it would be open to the public by 2017. Unlike the historical monument in India, it won’t consist only of walls and a roof. The humongous glass structure will be part of a hotel which will include facilities such as a retail shopping complex, banquet halls, and nightclubs.
        Taj Arabia will become a special attraction for tourists visiting the Emirates and the EXPO 2020 Dubai, to be held from October 2020 to April 2021, and which is expected to receive over 25 million visitors. Besides the architectural beauty, the place is expected to be financially rewarding, if things go as planned.
""","Current architectural skills make it possible to blend designs inspired by historic monuments with modern building designs.","The Taj Arabia will surpass the original Taj Mahal monument, because technological advances favour the builders.","The Taj Arabia will be a huge risk to the industrial investors, because the future returns may not match the investment they have already made.","The government of Dubai may scrap the project if the outcome of the glass structure does not come out the way it was originally planned."],
                                ["Which of the following most accurately summarizes the opinion of the author in the text?","Unlike proposed earlier, The Statue of Liberty wasn't erected by the joint effort of both the countries, rather it was a French gift to the Americans.","Laboulaye was never of the opinion that the memorial should be erected by utilizing the resources of France only.","The Statue of Liberty was fully built in the year 1870 by Bartholdi","The idea to build The Statue of Liberty was originated in America."],
                                ["Which of the following, most accurately summarizes the opinion of the author in the text?","He has a firm belief that until today no one has been able to replace Rembrandt's art.","He tried to prove that Rembrandt has not been completely understood by the critics.","He tried to portray that even though Rembrandt was highly regarded in the art world, his prowess and mettle was understood by only a few.","Rembrandt never believed in self-praise and publicizing, rather he was a silent artist."],
                                ["""
Dubai will now have its own Taj Mahal, a replica of the one located in India, which is considered one of the world’s Seven Wonders. It will be named Taj Arabia, and it will be a glass structure inspired by the shape of the Taj Mahal. Also, it will be 20 storeys high. The final work is expected to be finished by 2016, and it would be open to the public by 2017. Unlike the historical monument in India, it won’t consist only of walls and a roof. The humongous glass structure will be part of a hotel which will include facilities such as a retail shopping complex, banquet halls, and nightclubs.
        Taj Arabia will become a special attraction for tourists visiting the Emirates and the EXPO 2020 Dubai, to be held from October 2020 to April 2021, and which is expected to receive over 25 million visitors. Besides the architectural beauty, the place is expected to be financially rewarding, if things go as planned.
""","Current architectural skills make it possible to blend designs inspired by historic monuments with modern building designs.","The Taj Arabia will surpass the original Taj Mahal monument, because technological advances favour the builders.","The Taj Arabia will be a huge risk to the industrial investors, because the future returns may not match the investment they have already made.","The government of Dubai may scrap the project if the outcome of the glass structure does not come out the way it was originally planned."]]
    
    let Aryanswer : NSArray = ["Laboulaye was never of the opinion that the memorial should be erected by utilizing the resources of France only.",
                               "He tried to portray that even though Rembrandt was highly regarded in the art world, his prowess and mettle was understood by only a few.",
                               "Current architectural skills make it possible to blend designs inspired by historic monuments with modern building designs.",
                               "Laboulaye was never of the opinion that the memorial should be erected by utilizing the resources of France only.",
                               "He tried to portray that even though Rembrandt was highly regarded in the art world, his prowess and mettle was understood by only a few.",
                               "Current architectural skills make it possible to blend designs inspired by historic monuments with modern building designs."]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        btnPrevious.isHidden = true
        SetData(currentIndex: currentIndex)
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func SetData(currentIndex : Int){
        var objcgsize = CGSize ()
        let data : NSArray = aryDetails[currentIndex] as! NSArray
        lblQuestion.text = (data[0] as! String)
        btnAns1.setTitle((data[1] as! String), for: .normal)
        btnAns1.titleLabel?.numberOfLines = 0
        objcgsize =  btnAns1.findHeight(forText: btnAns1.titleLabel?.text, havingWidth: self.view.frame.width - 20, andFont: btnAns1.titleLabel?.font, padding: UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10))
        HeightBtnAns1.constant = objcgsize.height + 30
        btnAns1.cornerRadiusWithBorder(cornerRadius: 5, BorderWidth: 1, BorderColor: UIColor.blue.cgColor)
        
        
        btnAns2.setTitle((data[2] as! String), for: .normal)
        objcgsize = btnAns2.findHeight(forText: btnAns2.titleLabel?.text, havingWidth: self.view.frame.width - 20, andFont: btnAns2.titleLabel?.font, padding: UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10))
        btnAns2.titleLabel?.numberOfLines = 0
        HeightBtnAns2.constant = objcgsize.height + 30
        btnAns2.cornerRadiusWithBorder(cornerRadius: 5, BorderWidth: 1, BorderColor: UIColor.white.cgColor)
        
        btnAns3.setTitle((data[3] as! String), for: .normal)
        objcgsize =  btnAns3.findHeight(forText: btnAns3.titleLabel?.text, havingWidth: self.view.frame.width - 20, andFont: btnAns3.titleLabel?.font, padding: UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10))
        btnAns3.titleLabel?.numberOfLines = 0
        HeightBtnAns3.constant = objcgsize.height + 30
        btnAns3.cornerRadiusWithBorder(cornerRadius: 5, BorderWidth: 1, BorderColor: UIColor.white.cgColor)
        
        btnAns4.setTitle((data[4] as! String), for: .normal)
        objcgsize = btnAns4.findHeight(forText: btnAns4.titleLabel?.text, havingWidth: self.view.frame.width - 20, andFont: btnAns4.titleLabel?.font, padding: UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10))
        btnAns4.titleLabel?.numberOfLines = 0
        HeightBtnAns4.constant = objcgsize.height + 30
        btnAns4.cornerRadiusWithBorder(cornerRadius: 5, BorderWidth: 1, BorderColor: UIColor.white.cgColor)
    }
    
    @IBAction func btnPreviousClick(_ sender: Any) {
        resetButtonColor()
        btnNext.isHidden = false
        if currentIndex >= 0 {
            currentIndex -= 1
            if currentIndex == 0
            {
                btnPrevious.isHidden = true
            }
            SetData(currentIndex: currentIndex)
        }
    }
    
    @IBAction func btnNextClick(_ sender: Any) {
        resetButtonColor()
        btnPrevious.isHidden = false
        if currentIndex <= aryDetails.count - 1 {
            currentIndex += 1
            SetData(currentIndex: currentIndex)
            if currentIndex == aryDetails.count - 1
            {
                btnNext.isHidden = true
            }
            
        }
        
    }
    @IBAction func btnAnswerClick(_ sender: Any) {
        if btnSelectedAns.titleLabel?.text == Aryanswer[currentIndex] as? String {
            btnSelectedAns.backgroundColor = UIColor.green
        }
        else
        {
            
            for i in 11...14
            {
                let btn = view.viewWithTag(i) as! UIButton
                if i == btnSelectedAns.tag
                {
                    btnSelectedAns.backgroundColor = UIColor.red
                }
                else{
                    if btn.titleLabel?.text == Aryanswer[currentIndex] as? String {
                        btn.backgroundColor = UIColor.green
                    }
                }
            }
        }
    }
    @IBAction func btnAns1Click(_ sender: UIButton) {
        for i in 11...14
        {
            let btn = view.viewWithTag(i) as! UIButton
            if i == sender.tag
            {
                btnSelectedAns = btn
                btn.backgroundColor = UIColor.gray
            }
            else{
                btn.backgroundColor = UIColor(displayP3Red: 70.0/255.0, green: 19.0/255.0, blue: 94.0/255.0, alpha: 1.0)
            }
        }
    }
    
    func resetButtonColor(){
        for i in 11...14
        {
            let btn = view.viewWithTag(i) as! UIButton
            btn.backgroundColor = UIColor(displayP3Red: 70.0/255.0, green: 19.0/255.0, blue: 94.0/255.0, alpha: 1.0)
        }
    }
}

