//
//  ReorderTableHeaderView.swift
//  TableviewDemo
//
//  Created by Nirav Joshi on 11/10/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit

class ReorderTableHeaderView: UIView {
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    @IBOutlet weak var lblTitle: UILabel!
}
