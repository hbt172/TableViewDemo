//
//  ReorderVC.swift
//  TableviewDemo
//
//  Created by Nirav Joshi on 09/10/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit
import LongPressTableViewReordering
class ReorderVC: UIViewController,UITableViewDelegate,UITableViewDataSource,LongPressTableViewReorderDelegate {
   
    @IBOutlet var HeaderView: UIView!
    @IBOutlet weak var btnNext: UIButton!
    @IBOutlet weak var btnPrevious: UIButton!
    var isClickAnswer : Bool = false
    var currentIndex : Int = 0
    var objview = ReorderTableHeaderView()
    
    let aryHeader : NSArray = ["Which of the following most accurately summarizes the opinion of the author in the text? Which of the following most accurately summarizes the opinion of the author in the text? Which of the following most accurately summarizes the opinion of the author in the text? Which of the following most accurately summarizes the opinion of the author in the text? Which of the following most accurately summarizes the opinion of the author in the text? Which of the following most accurately summarizes the opinion of the author in the text? Which of the following most accurately summarizes the opinion of the author in the text? Which of the following most accurately summarizes the opinion of the author in the text? Which of the following most accurately summarizes the opinion of the author in the text? Which of the following most accurately summarizes the opinion of the author in the text Which of the following most accurately summarizes the opinion of the author in the text? Which of the following most accurately summarizes the opinion of the author in the text? Which of the following most accurately summarizes the opinion of the author in the text? Which of the following most accurately summarizes the opinion of the author in the text? Which of the following most accurately summarizes the opinion of the author in the text Which of the following most accurately summarizes the opinion of the author in the text? Which of the following most accurately summarizes the opinion of the author in the text? Which of the following most accurately summarizes the opinion of the author in the text? Which of the following most accurately summarizes the opinion of the author in the text? Which of the following most accurately summarizes the opinion of the author in the text","Unlike proposed earlier, The Statue of Liberty wasn't erected by the joint effort of both the countries, rather it was a French gift to the Americans.","Laboulaye was never of the opinion that the memorial should be erected by utilizing the resources of France only.","The Statue of Liberty was fully built in the year 1870 by Bartholdi","The idea to build The Statue of Liberty was originated in America.","Which of the following, most accurately summarizes the opinion of the author in the text?"]
    
    let aryDetails : NSArray = [["Which of the following most accurately summarizes the opinion of the author in the text?","Unlike proposed earlier, The Statue of Liberty wasn't erected by the joint effort of both the countries, rather it was a French gift to the Americans.","Laboulaye was never of the opinion that the memorial should be erected by utilizing the resources of France only.","The Statue of Liberty was fully built in the year 1870 by Bartholdi","The idea to build The Statue of Liberty was originated in America."],
                                ["Which of the following, most accurately summarizes the opinion of the author in the text?","He has a firm belief that until today no one has been able to replace Rembrandt's art.","He tried to prove that Rembrandt has not been completely understood by the critics.","He tried to portray that even though Rembrandt was highly regarded in the art world, his prowess and mettle was understood by only a few.","Rembrandt never believed in self-praise and publicizing, rather he was a silent artist."],
                                ["""
Dubai will now have its own Taj Mahal, a replica of the one located in India, which is considered one of the world’s Seven Wonders. It will be named Taj Arabia, and it will be a glass structure inspired by the shape of the Taj Mahal. Also, it will be 20 storeys high. The final work is expected to be finished by 2016, and it would be open to the public by 2017. Unlike the historical monument in India, it won’t consist only of walls and a roof. The humongous glass structure will be part of a hotel which will include facilities such as a retail shopping complex, banquet halls, and nightclubs.
        Taj Arabia will become a special attraction for tourists visiting the Emirates and the EXPO 2020 Dubai, to be held from October 2020 to April 2021, and which is expected to receive over 25 million visitors. Besides the architectural beauty, the place is expected to be financially rewarding, if things go as planned.
""","Current architectural skills make it possible to blend designs inspired by historic monuments with modern building designs.","The Taj Arabia will surpass the original Taj Mahal monument, because technological advances favour the builders.","The Taj Arabia will be a huge risk to the industrial investors, because the future returns may not match the investment they have already made.","The government of Dubai may scrap the project if the outcome of the glass structure does not come out the way it was originally planned."],
                                ["Which of the following most accurately summarizes the opinion of the author in the text?","Unlike proposed earlier, The Statue of Liberty wasn't erected by the joint effort of both the countries, rather it was a French gift to the Americans.","Laboulaye was never of the opinion that the memorial should be erected by utilizing the resources of France only.","The Statue of Liberty was fully built in the year 1870 by Bartholdi","The idea to build The Statue of Liberty was originated in America."],
                                ["Which of the following, most accurately summarizes the opinion of the author in the text?","He has a firm belief that until today no one has been able to replace Rembrandt's art.","He tried to prove that Rembrandt has not been completely understood by the critics.","He tried to portray that even though Rembrandt was highly regarded in the art world, his prowess and mettle was understood by only a few.","Rembrandt never believed in self-praise and publicizing, rather he was a silent artist."],
                                ["""
Dubai will now have its own Taj Mahal, a replica of the one located in India, which is considered one of the world’s Seven Wonders. It will be named Taj Arabia, and it will be a glass structure inspired by the shape of the Taj Mahal. Also, it will be 20 storeys high. The final work is expected to be finished by 2016, and it would be open to the public by 2017. Unlike the historical monument in India, it won’t consist only of walls and a roof. The humongous glass structure will be part of a hotel which will include facilities such as a retail shopping complex, banquet halls, and nightclubs.
        Taj Arabia will become a special attraction for tourists visiting the Emirates and the EXPO 2020 Dubai, to be held from October 2020 to April 2021, and which is expected to receive over 25 million visitors. Besides the architectural beauty, the place is expected to be financially rewarding, if things go as planned.
""","Current architectural skills make it possible to blend designs inspired by historic monuments with modern building designs.","The Taj Arabia will surpass the original Taj Mahal monument, because technological advances favour the builders.","The Taj Arabia will be a huge risk to the industrial investors, because the future returns may not match the investment they have already made.","The government of Dubai may scrap the project if the outcome of the glass structure does not come out the way it was originally planned."]]
    
    let aryReOrder : NSMutableArray = [["Which of the following most accurately summarizes the opinion of the author in the text?","Unlike proposed earlier, The Statue of Liberty wasn't erected by the joint effort of both the countries, rather it was a French gift to the Americans.","Laboulaye was never of the opinion that the memorial should be erected by utilizing the resources of France only.","The Statue of Liberty was fully built in the year 1870 by Bartholdi","The idea to build The Statue of Liberty was originated in America."],
                                ["Which of the following, most accurately summarizes the opinion of the author in the text?","He has a firm belief that until today no one has been able to replace Rembrandt's art.","He tried to prove that Rembrandt has not been completely understood by the critics.","He tried to portray that even though Rembrandt was highly regarded in the art world, his prowess and mettle was understood by only a few.","Rembrandt never believed in self-praise and publicizing, rather he was a silent artist."],
                                ["""
Dubai will now have its own Taj Mahal, a replica of the one located in India, which is considered one of the world’s Seven Wonders. It will be named Taj Arabia, and it will be a glass structure inspired by the shape of the Taj Mahal. Also, it will be 20 storeys high. The final work is expected to be finished by 2016, and it would be open to the public by 2017. Unlike the historical monument in India, it won’t consist only of walls and a roof. The humongous glass structure will be part of a hotel which will include facilities such as a retail shopping complex, banquet halls, and nightclubs.
        Taj Arabia will become a special attraction for tourists visiting the Emirates and the EXPO 2020 Dubai, to be held from October 2020 to April 2021, and which is expected to receive over 25 million visitors. Besides the architectural beauty, the place is expected to be financially rewarding, if things go as planned.
""","Current architectural skills make it possible to blend designs inspired by historic monuments with modern building designs.","The Taj Arabia will surpass the original Taj Mahal monument, because technological advances favour the builders.","The Taj Arabia will be a huge risk to the industrial investors, because the future returns may not match the investment they have already made.","The government of Dubai may scrap the project if the outcome of the glass structure does not come out the way it was originally planned."],
                                ["Which of the following most accurately summarizes the opinion of the author in the text?","Unlike proposed earlier, The Statue of Liberty wasn't erected by the joint effort of both the countries, rather it was a French gift to the Americans.","Laboulaye was never of the opinion that the memorial should be erected by utilizing the resources of France only.","The Statue of Liberty was fully built in the year 1870 by Bartholdi","The idea to build The Statue of Liberty was originated in America."],
                                ["Which of the following, most accurately summarizes the opinion of the author in the text?","He has a firm belief that until today no one has been able to replace Rembrandt's art.","He tried to prove that Rembrandt has not been completely understood by the critics.","He tried to portray that even though Rembrandt was highly regarded in the art world, his prowess and mettle was understood by only a few.","Rembrandt never believed in self-praise and publicizing, rather he was a silent artist."],
                                ["""
Dubai will now have its own Taj Mahal, a replica of the one located in India, which is considered one of the world’s Seven Wonders. It will be named Taj Arabia, and it will be a glass structure inspired by the shape of the Taj Mahal. Also, it will be 20 storeys high. The final work is expected to be finished by 2016, and it would be open to the public by 2017. Unlike the historical monument in India, it won’t consist only of walls and a roof. The humongous glass structure will be part of a hotel which will include facilities such as a retail shopping complex, banquet halls, and nightclubs.
        Taj Arabia will become a special attraction for tourists visiting the Emirates and the EXPO 2020 Dubai, to be held from October 2020 to April 2021, and which is expected to receive over 25 million visitors. Besides the architectural beauty, the place is expected to be financially rewarding, if things go as planned.
""","Current architectural skills make it possible to blend designs inspired by historic monuments with modern building designs.","The Taj Arabia will surpass the original Taj Mahal monument, because technological advances favour the builders.","The Taj Arabia will be a huge risk to the industrial investors, because the future returns may not match the investment they have already made.","The government of Dubai may scrap the project if the outcome of the glass structure does not come out the way it was originally planned."]]
    
    
    let aryAnswer: NSArray = [["Which of the following most accurately summarizes the opinion of the author in the text?","The Statue of Liberty was fully built in the year 1870 by Bartholdi","The idea to build The Statue of Liberty was originated in America.","Unlike proposed earlier, The Statue of Liberty wasn't erected by the joint effort of both the countries, rather it was a French gift to the Americans.","Laboulaye was never of the opinion that the memorial should be erected by utilizing the resources of France only."],
                              ["He tried to prove that Rembrandt has not been completely understood by the critics.","He tried to portray that even though Rembrandt was highly regarded in the art world, his prowess and mettle was understood by only a few.","Rembrandt never believed in self-praise and publicizing, rather he was a silent artist.","Which of the following, most accurately summarizes the opinion of the author in the text?","He has a firm belief that until today no one has been able to replace Rembrandt's art."],
                              ["""
Dubai will now have its own Taj Mahal, a replica of the one located in India, which is considered one of the world’s Seven Wonders. It will be named Taj Arabia, and it will be a glass structure inspired by the shape of the Taj Mahal. Also, it will be 20 storeys high. The final work is expected to be finished by 2016, and it would be open to the public by 2017. Unlike the historical monument in India, it won’t consist only of walls and a roof. The humongous glass structure will be part of a hotel which will include facilities such as a retail shopping complex, banquet halls, and nightclubs.
        Taj Arabia will become a special attraction for tourists visiting the Emirates and the EXPO 2020 Dubai, to be held from October 2020 to April 2021, and which is expected to receive over 25 million visitors. Besides the architectural beauty, the place is expected to be financially rewarding, if things go as planned.
""","The Taj Arabia will be a huge risk to the industrial investors, because the future returns may not match the investment they have already made.","The government of Dubai may scrap the project if the outcome of the glass structure does not come out the way it was originally planned.","Current architectural skills make it possible to blend designs inspired by historic monuments with modern building designs.","The Taj Arabia will surpass the original Taj Mahal monument, because technological advances favour the builders."],
                              ["Which of the following most accurately summarizes the opinion of the author in the text?","Unlike proposed earlier, The Statue of Liberty wasn't erected by the joint effort of both the countries, rather it was a French gift to the Americans.","Laboulaye was never of the opinion that the memorial should be erected by utilizing the resources of France only.","The Statue of Liberty was fully built in the year 1870 by Bartholdi","The idea to build The Statue of Liberty was originated in America."],
                              ["He tried to portray that even though Rembrandt was highly regarded in the art world, his prowess and mettle was understood by only a few.","Rembrandt never believed in self-praise and publicizing, rather he was a silent artist.","Which of the following, most accurately summarizes the opinion of the author in the text?","He has a firm belief that until today no one has been able to replace Rembrandt's art.","He tried to prove that Rembrandt has not been completely understood by the critics."],
                              ["""
Dubai will now have its own Taj Mahal, a replica of the one located in India, which is considered one of the world’s Seven Wonders. It will be named Taj Arabia, and it will be a glass structure inspired by the shape of the Taj Mahal. Also, it will be 20 storeys high. The final work is expected to be finished by 2016, and it would be open to the public by 2017. Unlike the historical monument in India, it won’t consist only of walls and a roof. The humongous glass structure will be part of a hotel which will include facilities such as a retail shopping complex, banquet halls, and nightclubs.
        Taj Arabia will become a special attraction for tourists visiting the Emirates and the EXPO 2020 Dubai, to be held from October 2020 to April 2021, and which is expected to receive over 25 million visitors. Besides the architectural beauty, the place is expected to be financially rewarding, if things go as planned.
""","Current architectural skills make it possible to blend designs inspired by historic monuments with modern building designs.","The Taj Arabia will surpass the original Taj Mahal monument, because technological advances favour the builders.","The Taj Arabia will be a huge risk to the industrial investors, because the future returns may not match the investment they have already made.","The government of Dubai may scrap the project if the outcome of the glass structure does not come out the way it was originally planned."]]
    
    @IBOutlet weak var tblReoder: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblReoder.register(UINib.init(nibName: "ReorderTableCell", bundle: Bundle.main), forCellReuseIdentifier: "ReorderTableCell")
        reorderer.enableLongPressReordering(for: tblReoder)
        // Do any additional setup after loading the view.
        tblReoder.rowHeight = 88.0
        tblReoder.estimatedRowHeight = UITableView.automaticDimension
       
        tblReoder.sectionHeaderHeight = UITableView.automaticDimension;
        tblReoder.estimatedSectionHeaderHeight = 25;
        
       SetHeaderView()
    }
    
    func SetHeaderView() {
        objview = (Bundle.main.loadNibNamed("ReorderTableHeaderView", owner: self, options: nil)?.first as? ReorderTableHeaderView)!
        
        objview.lblTitle.text = (aryHeader[currentIndex] as! String)
        objview.autoresizingMask = .flexibleWidth
        objview.frame = CGRect(origin: .zero, size: CGSize(width: self.view.frame.width, height: findHeightLabel(forText: (aryHeader[currentIndex] as! String), havingWidth: self.view.frame.size.width-20, andFont: objview.lblTitle.font, padding: UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)).height + 30))
        objview.translatesAutoresizingMaskIntoConstraints = true
        tblReoder.tableHeaderView = objview
    }
    
    /*
    override func viewWillLayoutSubviews() {
        HeaderView = UIView.init(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 200.0))
        
        let fittingSize = CGSize(width: tblReoder.bounds.width - (tblReoder.safeAreaInsets.left + tblReoder.safeAreaInsets.right), height: 0)
        let size = HeaderView.systemLayoutSizeFitting(fittingSize, withHorizontalFittingPriority: .required, verticalFittingPriority: .fittingSizeLevel)
        HeaderView.frame = CGRect(origin: .zero, size: size)
        tblReoder.tableHeaderView = HeaderView
        
    }*/
    
    
    
    
//    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
//    {
////        let objeView = tableView.dequeueReusableHeaderFooterView(withIdentifier: "ReorderTableHeaderView") as!   ReorderTableHeaderView
//        objview = (Bundle.main.loadNibNamed("ReorderTableHeaderView", owner: self, options: nil)?.first as? ReorderTableHeaderView)!
//        objview.lblTitle.text = (aryHeader[currentIndex] as! String)
//        return objview
//    }
//
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    
    fileprivate lazy var reorderer: LongPressTableViewReorderer = {
        let reorderer = LongPressTableViewReorderer()
        reorderer.delegate = self
        return reorderer
    }()
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return (aryDetails[currentIndex] as! NSArray).count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ReorderTableCell", for: indexPath) as! ReorderTableCell
        let ary = aryDetails[currentIndex] as! NSArray
        let objaryReorder = aryReOrder[currentIndex] as! NSArray
        let aryAnswer = self.aryAnswer[currentIndex] as! NSArray
        
        if isClickAnswer == true
        {
            cell.lblTitle.text = (objaryReorder[indexPath.row] as! String)
            print("\(indexPath.row)\(objaryReorder.index(of: aryAnswer[indexPath.row]))")
            if indexPath.row == objaryReorder.index(of: aryAnswer[indexPath.row])
            {
                cell.objView.backgroundColor = UIColor.green
            }
            else
            {
                cell.objView.backgroundColor = UIColor.red
            }
        }
        else{
            cell.lblTitle.text = (ary[indexPath.row] as! String)
            cell.objView.backgroundColor = UIColor(displayP3Red: 70.0/255.0, green: 19.0/255.0, blue: 94.0/255.0, alpha: 1.0)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func longPressReorderingDidBegin(in tableView: UITableView) {
        print("did begin")
    }
    
    func longPressReorderingDidEnd(in tableView: UITableView)
    {        
        print("did end \(reorderer.FromIndexPath!) \(reorderer.toIndexPath!)")
//        let aryData = (aryDetails[currentIndex] as! NSMutableArray)
        var aryData = NSMutableArray()
        if isClickAnswer == true{
             aryData = NSMutableArray(array: (aryReOrder[currentIndex] as! NSArray))
        }
        else{
            aryData = NSMutableArray(array: (aryDetails[currentIndex] as! NSArray))
        }
        
        print("did end \(aryData) \n\n\n \(aryReOrder[currentIndex]) \n\n\n  \(aryAnswer[currentIndex]) ")
        
        let strFrom = aryData[reorderer.FromIndexPath!.row]
        aryData.removeObject(at: reorderer.FromIndexPath!.row)
        aryData.insert(strFrom, at: reorderer.toIndexPath!.row)
        
        aryReOrder.replaceObject(at: currentIndex, with: aryData)
        
        print("after did end \(aryData) \n\n\n \(aryReOrder[currentIndex]) \n\n\n  \(aryAnswer[currentIndex])")
    }
    
    func GetReplaceIndexPath(from: IndexPath, to: IndexPath, in tableView: UITableView) {
//        let aryData = (aryDetails[currentIndex] as! NSMutableArray)
//        let strFrom = aryData[from.row]
//        aryData.removeObject(at: from.row)
//        aryData.insert(strFrom, at: to.row)
//        aryReOrder.replaceObject(at: to.row, with: aryData)
    }
    
    
    
    @IBAction func btnAnswerClick(_ sender: Any) {
        isClickAnswer = true
        tblReoder.reloadData()
    }
    @IBAction func btnPreviousClick(_ sender: Any) {
        isClickAnswer = false
        btnNext.isHidden = false
        if currentIndex >= 0 {
            currentIndex -= 1
            if currentIndex == 0
            {
                btnPrevious.isHidden = true
            }
            SetHeaderView()
            tblReoder.reloadData()
        }
    }
    @IBAction func btnNextClick(_ sender: Any) {
        isClickAnswer = false
        btnPrevious.isHidden = false
        if currentIndex <= aryDetails.count - 1 {
            currentIndex += 1
            SetHeaderView()
            tblReoder.reloadData()
            if currentIndex == aryDetails.count - 1
            {
                btnNext.isHidden = true
            }
            
        }
    }
    
    func findHeightLabel(forText text: String?, havingWidth widthValue: CGFloat, andFont font: UIFont?, padding: UIEdgeInsets) -> CGSize {
        var size = CGSize.zero
        if text != nil {
            var frame: CGRect? = nil
            if let aFont = font {
                frame = text?.boundingRect(with: CGSize(width: widthValue - padding.left - padding.right, height: CGFloat.greatestFiniteMagnitude), options: .usesLineFragmentOrigin, attributes: [NSAttributedString.Key.font: aFont], context: nil)
            }
            size = CGSize(width: frame?.size.width ?? 0.0, height: (frame?.size.height ?? 0.0) + 1)
        }
        return size
    }
}
