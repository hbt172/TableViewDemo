//
//  ButtonExtension.swift
//  TableviewDemo
//
//  Created by Nirav Joshi on 09/10/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import Foundation
import UIKit
extension UIButton
{
    func findHeight(forText text: String?, havingWidth widthValue: CGFloat, andFont font: UIFont?, padding: UIEdgeInsets) -> CGSize {
        var size = CGSize.zero
        if text != nil {
            var frame: CGRect? = nil
            if let aFont = font {
                frame = text?.boundingRect(with: CGSize(width: widthValue - padding.left - padding.right, height: CGFloat.greatestFiniteMagnitude), options: .usesLineFragmentOrigin, attributes: [NSAttributedString.Key.font: aFont], context: nil)
            }
            size = CGSize(width: frame?.size.width ?? 0.0, height: (frame?.size.height ?? 0.0) + 1)
        }
        return size
    }
    
    func cornerRadiusWithBorder(cornerRadius : CGFloat,BorderWidth : CGFloat,BorderColor : CGColor)
    {
        self.layer.cornerRadius = cornerRadius
        self.layer.borderWidth = BorderWidth
        self.layer.borderColor = BorderColor
    }
}
