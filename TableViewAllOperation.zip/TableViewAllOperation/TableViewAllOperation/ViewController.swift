//
//  ViewController.swift
//  TableViewAllOperation
//
//  Created by Nirav Joshi on 27/09/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
   
    var aryName : NSMutableArray = ["Hardik","Bhargav","Darshit"]
    var aryImage : NSMutableArray = [#imageLiteral(resourceName: "Image1"),#imageLiteral(resourceName: "Image2"),#imageLiteral(resourceName: "Image1")]
    @IBOutlet weak var tblEmployee: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblEmployee.register(UINib.init(nibName: "EmployeeTableViewCell", bundle: Bundle.main), forCellReuseIdentifier: "EmployeeTableViewCell")
        // Do any additional setup after loading the view, typically from a nib.
        
        
        let results = [[5,2,7], [4,8], [9,1,3,4]]
        let allResults = results.reduce([],+)
        let alljoind = Array(results.joined())
        
        // [5, 2, 7, 4, 8, 9, 1, 3]
        print("\(allResults) \(alljoind)")
        
        var quotesArray = [
            ["quote": "Some text here", "author": "Some guy"],
            ["quote": "Some text here1", "author": "Some guy1"],
            ["quote": "Some text here2", "author": "Some guy2"]
        ]

        for i in 0...quotesArray.count - 1
        {
            print(i)
            print(quotesArray[i])
            for (key,value) in quotesArray[i]
            {
                print("\(key),\(value)")
            }
        }
        
        
        var quotesArray1 = ["First" : [ "Two" : [
            ["quote": "Some text here", "author": "Some guy"],
            ["quote": "Some text here1", "author": "Some guy1"],
            ["quote": "Some text here2", "author": "Some guy2"]]]
        ]
        
        
        let dict1 = quotesArray1["First"]
        print(dict1!["Two"]  as Any)
        
        var ary = dict1!["Two"]!
        ary[0] = ["quote" : "abd" , "author" : "sdasdf" ]
        
        for item in dict1!["Two"]!
        {
            
            print("\(item["quote"]!)\(item["author"]!)")
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : EmployeeTableViewCell = tableView.dequeueReusableCell(withIdentifier: "EmployeeTableViewCell", for: indexPath) as! EmployeeTableViewCell
        cell.lblEName.text = (aryName[indexPath.row] as! String)
        cell.imgViewEmployee.image = (aryImage[indexPath.row] as! UIImage)
       

//        let clearView = UIView()
//
//        clearView.backgroundColor = UIColor.clear // Whatever color you like
//        cell.selectedBackgroundView = clearView
//
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let editAction = UITableViewRowAction(style: .normal, title: "Edit") { (rowAction, indexPath) in
            //TODO: edit the row at indexPath here
        }
        editAction.backgroundColor = .blue
        
        let deleteAction = UITableViewRowAction(style: .normal, title: "Delete") { (rowAction, indexPath) in
            //TODO: Delete the row at indexPath here
        }
        deleteAction.backgroundColor = .red
        
        return [editAction,deleteAction]
    }
   
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return aryName.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
       print("abcdef")
       tableView.deselectRow(at: indexPath, animated: false)
        if let cell = tableView.cellForRow(at: indexPath as IndexPath) {
            if cell.accessoryType == .checkmark{
                cell.accessoryType = .none
            }
            else{
                cell.accessoryType = .checkmark
            }
        }
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        print("abcd")
    }
    
    func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCellEditingStyle {
        return .none
    }
    
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        print("willdisplay")
    }
    
    @IBAction func btnPlusClick(_ sender: Any) {
        tblEmployee.isEditing = true
//        tblEmployee.allowsSelection = true
//        tblEmployee.allowsMultipleSelection = true
//        tblEmployee.allowsMultipleSelectionDuringEditing = true

    }
}

